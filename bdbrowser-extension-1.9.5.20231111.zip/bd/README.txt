Put the betterdiscord.asar or BetterDiscord's renderer.js in this folder to use a local version that overrides the VFS.
